# Digi-Tech — Global Software Engineering Services Website

A modern, minimalist, and multilingual professional website showcasing software engineering services focused on:

- Web and mobile application design & development
- Digital transformation initiatives
- AI product integration and UX modernization

The site is designed for a seamless user experience, global accessibility, and straightforward deployment to reliable hosting platforms.

## Project Structure

- `index.html` — Semantic page layout and content sections
- `styles.css` — Responsive, minimalist visual design system
- `script.js` — Multilingual UI + AI-style recommendation interaction
- `admin_backend.py` — Flask + SQLite backend for admin route and APIs
- `templates/admin_login.html` — Secure admin login page (email/password)
- `templates/admin_dashboard.html` — Admin project/payment dashboard
- `static/admin-auth.css` — Login page styling
- `static/admin.css` — Dashboard styling
- `static/admin.js` — Dashboard interactions (including Edit/Delete actions)
- `deploy/hostinger/*` — Hostinger VPS env, Nginx, and systemd examples
- `docs/hostinger-deployment.md` — Public/internal split deployment guide

## Included Features

### 1) Modern, user-friendly design

- Clean dark-theme aesthetic with strong readability
- Responsive layout for desktop, tablet, and mobile
- Clear content hierarchy and conversion-focused CTAs

### 2) AI-driven experience

- Interactive recommendation assistant that suggests service pathways based on visitor inputs
- Personalized output model to guide users toward relevant engagement options

### 3) Multilingual support

- Built-in language switching for:
  - English (`en`)
  - Spanish (`es`)
  - French (`fr`)
  - Arabic (`ar`, RTL supported)
- Client-side translation dictionary architecture that can be extended easily

### 4) Accessibility foundation

- Semantic landmarks (`header`, `main`, `section`, `footer`)
- Skip link for keyboard users
- Focus-visible states and keyboard-friendly controls
- RTL-aware layout behavior for Arabic

### 5) Reliable hosting readiness

This website is static and can be deployed globally with high reliability on platforms such as:

- **Cloudflare Pages**
- **Netlify**
- **Vercel**
- **AWS S3 + CloudFront**

Recommended production setup:

- Global CDN enabled
- HTTPS (SSL/TLS) enforced
- Caching headers configured
- Monitoring and uptime alerts enabled

## Run Locally

### Public website (static)

```bash
python3 -m http.server 8080
```

Then open:

`http://localhost:8080`

### Admin dashboard (with project/payment tracking)

Install dependencies:

```bash
python3 -m pip install -r requirements.txt
```

Run backend:

```bash
python3 admin_backend.py
```

Then open:

- `http://localhost:5000/admin/login`
- `http://localhost:5000/admin`

> Note: admin routes are available only when `APP_DEPLOY_TARGET=admin_internal`.
> For local admin testing:
>
> ```bash
> APP_DEPLOY_TARGET=admin_internal APP_PORT=5000 python3 admin_backend.py
> ```

Default local admin credentials:

- Email: `admin@digi-tech.local`
- Password: `ChangeMe123!`

Set production credentials via env vars:

- `ADMIN_EMAIL`
- `ADMIN_PASSWORD` (or `ADMIN_PASSWORD_HASH`)
- `FLASK_SECRET_KEY`

### Deployment modes (important)

`admin_backend.py` supports two deployment targets:

- `APP_DEPLOY_TARGET=public`
  - Admin module disabled (`/admin` and `/api/admin/*` return 404)
  - Exposes public website + public API routes only
- `APP_DEPLOY_TARGET=admin_internal`
  - Admin module enabled for internal staff use
  - Supports login + admin dashboard + admin APIs

Public API routes available in `public` mode:

- `GET /api/public/health`
- `POST /api/public/inquiries`

## Hostinger VPS deployment (public + internal split)

Use two app processes and two subdomains:

- `yourdomain.com` → public app (`APP_DEPLOY_TARGET=public`, port `5000`)
- `admin.yourdomain.com` → internal admin app (`APP_DEPLOY_TARGET=admin_internal`, port `5001`)

Reference files:

- `deploy/hostinger/public.env.example`
- `deploy/hostinger/admin.env.example`
- `deploy/hostinger/nginx-public.conf`
- `deploy/hostinger/nginx-admin-internal.conf`
- `deploy/hostinger/systemd/digi-tech-public.service`
- `deploy/hostinger/systemd/digi-tech-admin.service`

Internal admin protection should use both:

1. Nginx IP allowlist (`allow`/`deny`) on `admin.yourdomain.com`
2. App-level session auth (email/password)

## Customization Notes

- Replace `Digi-Tech` branding and copy in `index.html`
- Update contact email in the contact CTA (`mailto:` link)
- Add more languages by extending the `translations` object in `script.js`
- Integrate analytics (e.g., Plausible, GA4) and form backend if needed

## Next Production Enhancements (Optional)

- Connect contact form to CRM/email automation
- Add case studies and testimonials
- Add CMS-backed localization workflow
- Add structured data (JSON-LD) for SEO
